<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>GUI</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-01-22T10:39:51</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>36f87d63-f733-44ae-b978-73acf370dde9</testSuiteGuid>
   <testCaseLink>
      <guid>f2b3ae48-3248-4b0d-a148-91d024650721</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_03</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
