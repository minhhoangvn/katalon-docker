<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Non-GUI</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-01-25T13:38:14</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>587e5c8c-fac6-4fa4-aab1-440d7b8784ef</testSuiteGuid>
   <testCaseLink>
      <guid>a2f10dcc-4d9f-4b28-ae0c-216e72ffbbc0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_01</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d9ae41aa-13f8-4de6-bbfe-a240e5b05a80</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_02</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
