katalon -runMode=console -consoleLog -projectPath="/Users/minhhoang/Workspace/WorkSpace/Docker/Katalon-Container/TestSample/TestSample.prj" -testSuitePath=Test\ Suites/GUI -browserType=Chrome
